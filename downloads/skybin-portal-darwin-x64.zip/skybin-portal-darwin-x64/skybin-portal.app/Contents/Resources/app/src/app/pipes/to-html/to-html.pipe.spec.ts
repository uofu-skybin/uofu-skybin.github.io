import { ToHtmlPipe } from './to-html.pipe';

describe('ToHtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new ToHtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
