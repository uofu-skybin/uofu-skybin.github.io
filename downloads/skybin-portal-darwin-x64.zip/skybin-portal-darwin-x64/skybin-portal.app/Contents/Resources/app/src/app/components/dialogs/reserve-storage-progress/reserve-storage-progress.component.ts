import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-reserve-storage-progress',
  templateUrl: './reserve-storage-progress.component.html',
  styleUrls: ['./reserve-storage-progress.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ReserveStorageProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
